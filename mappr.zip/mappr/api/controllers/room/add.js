module.exports = async function add(req, res) {

  return res.view('add');


}